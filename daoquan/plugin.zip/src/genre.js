
function execute() {
    return Response.success([
        {title: "Tất cả", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1", script: "gen.js"},
        {title: "Tiên Hiệp", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=1", script: "gen.js"},
        {title: "Đô Thị", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=10", script: "gen.js"},
        {title: "Khoa Huyễn", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=11", script: "gen.js"},
        {title: "Kỳ Huyễn", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=17", script: "gen.js"},
        {title: "Võ Hiệp", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=12", script: "gen.js"},
        {title: "Lịch Sử", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=3", script: "gen.js"},
        {title: "Đồng Nhân", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=13", script: "gen.js"},
        {title: "Quân Sự", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=2", script: "gen.js"},
        {title: "Võng Du", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=14", script: "gen.js"},
        {title: "Quan Trường", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=15", script: "gen.js"},
        {title: "Linh Dị", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=18", script: "gen.js"},
        {title: "Ngôn Tình", input:  "https://daoquan.vn/tim-kiem-tong-hop?type=1&pCate=16", script: "gen.js"}
    ]);
}



